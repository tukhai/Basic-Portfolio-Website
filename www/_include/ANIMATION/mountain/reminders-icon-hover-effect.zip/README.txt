A Pen created at CodePen.io. You can find this one at http://codepen.io/Gameintosh/pen/BwAxn.

 Recreating the similar effect from original Apple video of OS X Yosemite.