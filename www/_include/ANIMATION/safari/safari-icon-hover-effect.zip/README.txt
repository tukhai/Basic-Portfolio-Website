A Pen created at CodePen.io. You can find this one at http://codepen.io/Gameintosh/pen/sAioC.

 Recreating the similar effect from original Apple video of OSX Yosemite.