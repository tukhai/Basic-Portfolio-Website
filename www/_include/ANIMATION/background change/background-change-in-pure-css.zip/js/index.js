/*

  Unfortunately, this method is somewhat impractical as you
  have to place background elements after the button and set
  a smaller z-index which requires absolute/fixed positioning.
  Still, not that big of a deal with only a few elements
  and it looks cool.

  ---

  Changelog:

  4/10/2016
  * Figured out I wasn't that bright while writing
    the original code
  * Cleaned and improved the code
  * Changed Slim to Jade and Sass to Stylus - not because
    they're better or anything, I just wanted to
  * Spent a few minutes to come up with some clever changelog
    message

  12/9/2014
  * Made some miscellaneous improvements
  * Cleaned the code even, even more

  9/20/2014
  * Improved fallback for larger resolutions
  * Cleaned the code even more

  9/17/2014
  * Translated HTML to Slim and CSS to Sass for easier
    editing
  * Made some small fixes and removed headers
  * Fixed the images again

  6/7/2014
  * Fixed the images

*/