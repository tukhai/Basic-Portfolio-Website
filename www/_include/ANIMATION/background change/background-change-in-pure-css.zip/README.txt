A Pen created at CodePen.io. You can find this one at http://codepen.io/miroot/pen/nBEqk.

 Smooth animated background change made with pure CSS.
Please, read my comment in JS box.