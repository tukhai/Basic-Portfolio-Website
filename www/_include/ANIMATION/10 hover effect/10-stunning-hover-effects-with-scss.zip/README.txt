A Pen created at CodePen.io. You can find this one at http://codepen.io/caraujo/pen/LVPzxO.

 A small collection of stylish effects with Scss. See also: 10 hover effects with less: http://codepen.io/caraujo/details/VYOjNM

30k views!
YAY!