A Pen created at CodePen.io. You can find this one at http://codepen.io/donovanh/pen/iBolr.

 An example from blog post: http://cssanimation.rocks/spheres