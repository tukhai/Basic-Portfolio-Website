A Pen created at CodePen.io. You can find this one at http://codepen.io/sol0mka/pen/iHtsL.

 Do not hover this trash.