A Pen created at CodePen.io. You can find this one at http://codepen.io/waynedunkley/pen/YPJWaz.

 Solar system with 3D animations built entirely with CSS3. Solar system stops at Jupiter as the size would be too large for smaller displays