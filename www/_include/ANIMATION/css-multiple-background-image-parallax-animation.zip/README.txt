A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/EgpNNG.

 If you have enabled images instead of iframes for pen previews, you'll see a city, but it's gone now.