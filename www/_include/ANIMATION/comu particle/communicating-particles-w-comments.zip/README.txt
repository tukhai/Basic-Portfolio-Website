A Pen created at CodePen.io. You can find this one at http://codepen.io/Godje/pen/zKazNq.

 Object Oriented Goo.
LC - add points
RC - remove points
